<?php
// Silence is golden and we also agree it :)